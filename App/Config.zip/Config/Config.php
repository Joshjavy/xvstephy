<?php

namespace App\Config;

class Config
{
    
    const DB_HOST    = '127.0.0.1';
    const DB_PORT    = '3306';
    const DB_NAME    = 'xvstephy';
    const DB_USER    = 'root';
    const DB_PASS    = '';
    const DB_CHARSET = 'utf8mb4';
}
