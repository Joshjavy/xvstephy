<?php

namespace App\Config;

class env
{
    const site    = 'http://xvstephy.test:8080/';//Dominio
}
